<br>

<div class="alert alert-success">
	
	<marquee><b>HÒA KÍNH CHÀO CÁC ĐỒNG DÂM, CÁC ĐỒNG DÂM NẠP TIỀN QUA ATM VIETCOMBANK - VIETTINBANK  - MOMO - TCSR NHÉ LH:01697.416.497</b></marquee>
</div>
<br>
<div class="col-md-12">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h3 class="panel-title">Đăng nhập và đăng ký</h3>
		</div>
		<div class="panel-body">
<div id="result_html">

								<div class="alert alert-default">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
									<strong>NHẬP USERNAME VÀ PASSWORD WEB TỰ ĐỘNG ĐĂNG NHẬP VÀ ĐĂNG KÝ NHÉ.
</strong> 
								</div>

						    </div>
		      					<form action="" method="POST" role="form" id="login_form">
		      						<div class="form-group">
		      							<label for="email">* Email: </label>
		      							<input type="text" class="form-control email" id="email" placeholder="Vui lòng nhập email" name="email" required="">
		      						</div>
		      						<div class="form-group">
		      							<label for="password">* Mật khẩu: </label>
		      							<input type="password" class="form-control password" id="password" placeholder="***********" name="password" required=""> 
		      						</div>
		      						<input type="hidden" name="<?=$csrf_token['name']?>" value="<?=$csrf_token['hash']?>">
		      						<center><button type="submit" class="btn btn-primary btn-block" id="reg_account">Đăng nhập & Đăng ký</button></center>
		      					</form>
		</div>
	</div>
</div>
<div class="col-md-8">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h3 class="panel-title">Loại hàng bày bán</h3>
		</div>
		<div class="panel-body">
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
						<tr>
							
							<th>Loại</th>
							<th>Đã bán</th>
							<th>Còn lại</th>
							<th>Bảng giá/ clone</th>
							<th>Trạng thái</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							
							<th>Veri trắng</th>
							<th>50</th>
							<th>2154</th>
							<th>2.000 vnđ</th>
							<th><p class="text-success"><span class="glyphicon glyphicon-ok"></span> Còn hàng</p></th>
						</tr>

						<tr>
							
							<th>Veri có avatar</th>
							<th>50</th>
							<th>2154</th>
							<th>2.000 vnđ</th>
							<th><p class="text-success"><span class="glyphicon glyphicon-ok"></span> Còn hàng</p></th>
						</tr>
						<tr>
							
							<th>NoVeri trắng</th>
							<th>50</th>
							<th>2154</th>
							<th>2.000 vnđ</th>
							<th><p class="text-success"><span class="glyphicon glyphicon-ok"></span> Còn hàng</p></th>
						</tr>
						<tr>
							
							<th>Veri có avatar</th>
							<th>50</th>
							<th>2154</th>
							<th>2.000 vnđ</th>
							<th><p class="text-success"><span class="glyphicon glyphicon-ok"></span> Còn hàng</p></th>
						</tr>
						<tr>
							
							<th>Veri có fr</th>
							<th>50</th>
							<th>2154</th>
							<th>2.000 vnđ</th>
							<th><p class="text-success"><span class="glyphicon glyphicon-ok"></span> Còn hàng</p></th>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="col-md-4">
	<div class="panel panel-info">
		<div class="panel-heading">
			<h3 class="panel-title">Lịch sử mua hàng</h3>
		</div>
		<div class="panel-body" style="height: 325px; overflow: scroll;"> 
				<ul class="list-group">
					<li class="list-group-item">Item 1</li>
					<li class="list-group-item">Item 2</li>
					<li class="list-group-item">Item 3</li>
					<li class="list-group-item">Item 3</li>
					<li class="list-group-item">Item 3</li>
					<li class="list-group-item">Item 3</li>
					<li class="list-group-item">Item 3</li>
					<li class="list-group-item">Item 3</li>
					<li class="list-group-item">Item 3</li>
					<li class="list-group-item">Item 3</li>
				</ul>
		</div>
	</div>
</div>
<div class="col-md-12">
	
<div class="panel panel-info">
		<div class="panel-heading">
			<h3 class="panel-title">Cam kết khách hàng</h3>
		</div>
<div class="panel-body">
<div class="col-sm-12 col-xs-12">





    <div class="col-md-4">





        <div class="panel panel-default">





            <div class="panel-body text-center">

                <div class="et_pb_main_blurb_image"><img width="100px" src="/assets/image/1.png" alt="" class="et-waypoint et_pb_animation_off et-animated"></div>

                <div class="et_pb_blurb_container">

                    <h4>Công nghệ mới</h4>



                    <p>Công nghệ mới giúp bạn hoàn toàn chủ động số lượng clone,token muốn mua hoàn toàn do bạn chủ động.</p>



                </div>

            </div>

            <!-- .et_pb_blurb_content -->

        </div>

        <!-- .et_pb_blurb -->

    </div>

    <!-- .et_pb_column -->

    <div class="col-md-4">





        <div class="panel panel-default">





            <div class="panel-body text-center">

                <div class="et_pb_main_blurb_image"><img width="100px" src="/assets/image/2.png" alt="" class="et-waypoint et_pb_animation_off et-animated"></div>

                <div class="et_pb_blurb_container">

                    <h4>Chi phí thấp</h4>



                    <p>Chi phí hầu như rất vừa với túi tiền của các bạn, nên rất được ưa chuông dịch vụ này.</p>



                </div>

            </div>

            <!-- .et_pb_blurb_content -->

        </div>

        <!-- .et_pb_blurb -->

    </div>

    <!-- .et_pb_column -->

    <div class="col-md-4">





        <div class="panel panel-default">





            <div class="panel-body text-center">

                <div class="et_pb_main_blurb_image"><img width="100px" src="/assets/image/3.png" alt="" class="et-waypoint et_pb_animation_off et-animated"></div>

                <div class="et_pb_blurb_container">

                    <h4>Bảo Mật An Toàn</h4>



                    <p>Chúng tôi không bán token cho nhiều người. Khi bạn mua token hệ thống sẽ lưu trữ lại, dùng đến đâu lấy đến đó.

                    .</p>



                </div>

            </div>

            <!-- .et_pb_blurb_content -->

        </div>

        <!-- .et_pb_blurb -->

    </div>

    <!-- .et_pb_column -->

</div>
</div>
</div>

</div>